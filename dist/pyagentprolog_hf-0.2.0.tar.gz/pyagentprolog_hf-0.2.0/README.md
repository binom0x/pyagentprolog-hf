# pyagentprolog-hf

Hugging Face integration for [PyAgentProlog](https://github.com/yourusername/pyagentprolog).

Позволяет использовать Prolog-движок PyAgentProlog как обычную HF-модель:

* `PyAgentPrologModel.from_pretrained(...)` / `save_pretrained(...)`
* `AutoModel.from_pretrained(..., trust_remote_code=True)`
* `pipeline("prolog", model=...)`
* `push_to_hub(...)` для публикации моделей на HF Hub

## Установка

```bash
# Ядро устанавливается автоматически как зависимость
pip install pyagentprolog-hf

# С семантической унификацией (sentence-transformers)
pip install pyagentprolog-hf[semantic-st]

# С Ollama-эмбеддингами
pip install pyagentprolog-hf[semantic-ollama]

# С CLI для HF Hub
pip install pyagentprolog-hf[hub]

# Всё сразу
pip install pyagentprolog-hf[all]